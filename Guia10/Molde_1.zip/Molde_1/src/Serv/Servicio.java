/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Serv;

import Entidades.Alumno;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author juan
 */
public class Servicio {
    /**
     * Crear una clase llamada Alumno que mantenga información sobre las notas
     * de distintos alumnos. La clase Alumno tendrá como atributos, su nombre y
     * una lista de tipo Integer con sus 3 notas. En el servicio de Alumno
     * deberemos tener un bucle que crea un objeto Alumno. Se pide toda la
     * información al usuario y ese Alumno se guarda en una lista de tipo Alumno
     * y se le pregunta al usuario si quiere crear otro Alumno o no. Después de
     * ese bucle tendremos el siguiente método en el servicio de Alumno: Método
     * notaFinal(): El usuario ingresa el nombre del alumno que quiere calcular
     * su nota final y se lo busca en la lista de Alumnos. Si está en la lista,
     * se llama al método. Dentro del método se usará la lista notas para
     * calcular el promedio final de alumno. Siendo este promedio final,
     * devuelto por el método y mostrado en el main.
     */

    /**
     * En el servicio de Alumno deberemos tener un bucle que crea un objeto
     * Alumno.
     */
    static Scanner entrada = new Scanner(System.in).useDelimiter("\n");
    public static Alumno crearObjetos(){
        ArrayList <Double> notas = new ArrayList();
        System.out.println("Ingrese nombre del alumno: ");
        String nombre = entrada.next();
        for (int i = 0; i < 3; i++) {
            System.out.println("Ingrese la nota N: " );
            notas.add(entrada.nextDouble());
        }
        return new Alumno(nombre,notas);
        
    }
    public static ArrayList <Alumno> lista(){
        ArrayList <Alumno> Alumno = new ArrayList();
        String resp = "";
        while (!resp.equalsIgnoreCase("N")) {
            Alumno.add(Servicio.crearObjetos());
            System.out.println("Desea seguir ingresando alumnos: ");
            resp = entrada.next().substring(0, 1);
        }
        return Alumno;
    }
    
    /**
     * Si se encotro el alumno
     */
    
    public static double AlumnoEncontrado(ArrayList <Alumno> Alumnos){
        System.out.println("Ingrese el alumno a buscar: ");
        String nombre = entrada.next();
        
        for (Alumno Alumno1 : Alumnos) {
            if (Alumno1.getNombre().equalsIgnoreCase(nombre)) {
                return notaFinal(Alumno1);
            }
        }
        return 0;
    }
    public static double notaFinal(Alumno obj){
        double promedio = 0;
        for (double notas : obj.getNotas()) {
            promedio += notas;
        }
        promedio = promedio / 3;
        return promedio;
    }
    
}
